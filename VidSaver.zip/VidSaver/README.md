# VidSaver — Android Video Downloader

YouTube, Facebook, Instagram, TikTok (ar yt-dlp jei site support kore, 1000+) theke video (MP4) ba audio (MP3) download kore.
Engine: [yt-dlp](https://github.com/yt-dlp/yt-dlp) + ffmpeg, via [youtubedl-android](https://github.com/yausername/youtubedl-android).

## Features
- Link paste koro (📋 button) → **Video (MP4)** ba **Audio (MP3)** select → **Download**
- YouTube/FB/Insta/TikTok app-e **Share → VidSaver** dile link auto boshe jay
- Progress bar, ETA, cancel, log
- File save hoy: `Download/VidSaver/`
- Din-e ekbar yt-dlp auto-update hoy; "Update yt-dlp" button-o ache (kono site kaj na korle eta chapo)
- Android 8.0+ (API 26+)

## APK banano — PC chara (GitHub diye)
1. github.com-e ekta notun repository banao (e.g. `VidSaver`).
2. Ei folder-er shob file (`.github` folder shoho) repo-te upload/push koro.
3. Repo-r **Actions** tab → "Build APK" workflow automatic chalbe (~8–12 min). Na challe **Run workflow** chapo.
4. Shesh hole run-e dhuke niche **Artifacts → VidSaver-APKs** download koro (zip).
5. Zip-er moddhe `app-arm64-v8a-debug.apk` phone-e install koro (beshirbhag phone arm64). Purono phone hole `armeabi-v7a` ta.
   Install-er shomoy "Install unknown apps" allow korte hobe.

## APK banano — PC diye (Android Studio)
Android Studio-te folder open koro → Build → Build APK(s). Ba terminal-e: `./gradlew assembleDebug`

## Limitation
- Private video, login-lagbe emon Instagram/Facebook post download hobe na (cookies support nai).
- Site-gulo prayi change kore; kaj na korle "Update yt-dlp" chapo.
- Shudhu nijer ba permission ache emon content download koro — platform-er Terms of Service ar copyright mene cholo.
