# VidSaver — Android Video Downloader

YouTube, Facebook, Instagram, TikTok, Threads (ar yt-dlp jei site support kore, 1000+) theke video (MP4) ba audio (MP3) download kore.
Engine: [yt-dlp](https://github.com/yt-dlp/yt-dlp) + ffmpeg, via [youtubedl-android](https://github.com/yausername/youtubedl-android).

## Features
- Quality dropdown: default **Auto (best)**; chaile 2160p / 1440p / 1080p / 720p / 480p / 360p / 240p
- MP3: **Auto** ba 320 / 256 / 192 / 128 kbps
- **Auto download**: link share ba paste korlei download shuru (switch diye bondho kora jay)
- Download fail korle app nijei ekbar sohoj setting-e abar cheshta kore
- Link paste koro (📋 button) → **Video (MP4)** ba **Audio (MP3)** select → **Download**
- YouTube/FB/Insta/TikTok app-e **Share → VidSaver** dile link auto boshe jay
- Progress bar, ETA, cancel, log
- File save hoy: `Download/VidSaver/`
- Din-e ekbar yt-dlp auto-update hoy; "Update yt-dlp" button-o ache (kono site kaj na korle eta chapo)
- Android 8.0+ (API 26+)

## APK banano — PC chara (GitHub diye)
1. github.com-e ekta notun repository banao (e.g. `VidSaver`).
2. Ei folder-er shob file (`.github` folder shoho) repo-te upload/push koro.
3. Repo-r **Actions** tab → "Build APK" workflow automatic chalbe (~8–12 min). Na challe **Run workflow** chapo.
4. Shesh hole run-e dhuke niche **Artifacts → VidSaver-APKs** download koro (zip).
5. Zip-er moddhe `app-arm64-v8a-debug.apk` phone-e install koro (beshirbhag phone arm64). Purono phone hole `armeabi-v7a` ta.
   Install-er shomoy "Install unknown apps" allow korte hobe.

## APK banano — PC diye (Android Studio)
Android Studio-te folder open koro → Build → Build APK(s). Ba terminal-e: `./gradlew assembleDebug`

## Threads
yt-dlp-e Threads nei, tai public-domain [yt-dlp-threads](https://github.com/tribixbite/yt-dlp-threads) plugin `app/src/main/assets/ytdlp-plugins/` e bundle kora ache. Shudhu public video post kaj kore.

## Ads (AdMob)
Main screen-e niche ekta banner ad ache. Ekhon Google-er TEST ID boshano.
Nijer ID dite `app/src/main/res/values/ads.xml` file-e `admob_app_id` ar `admob_banner_id` bodlao, tarpor abar build koro.

## Auto-update system
- GitHub-e protibar push/upload korle notun version toiri hoy: `1.3.<build number>` (versionCode = 100 + build number).
- Boro update-e version bodlate `gradle.properties`-e `appVersion=1.3` ke `2.0` koro.
- Workflow signed APK soho ekta **GitHub Release** banay. Commit message-ta hoy "What's new".
- App khulle (3 ghontay ekbar) ba "Check for app update" chaple Release check kore → **Update now** → download → install.
- Repo **Public** hote hobe (private repo-r Release app dekhte pay na).

### Signing key
Key-ta project-ei ache: `app/keystore/vidsaver-release.jks` (password `app/build.gradle.kts`-e).
Ei file bodlaba na ba muchba na — bodlale ager install kora app ar update nibe na. Ekta backup rekho.

## Limitation
- Kono login lage na. Tobe private account-er video, ba je video site nije login chhara dekhay na, segulo namano jabe na.
- Site-gulo prayi change kore; kaj na korle "Update yt-dlp" chapo.
- Shudhu nijer ba permission ache emon content download koro — platform-er Terms of Service ar copyright mene cholo.

## Branding & Copyright
- App icon: `branding/VidSaver_app_icon.png` (launcher icon `res/mipmap-*/ic_launcher_foreground.png`).
- KKsarkar logo: `branding/KKsarkar_logo.png` (app-er niche dekhay).
- © 2026 KKsarkar. All rights reserved. Details: [NOTICE.md](NOTICE.md)
