plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val youtubedlAndroid = "0.18.1"

// ---------------- Versioning ----------------
// appVersion (major.minor) lives in gradle.properties. GitHub Actions passes -PbuildNumber=<run number>,
// so every build gets a new version automatically:  1.3.<build>,  versionCode = 100 + <build>.
val appVersion = (project.findProperty("appVersion") as String?) ?: "1.3"
val buildNumber = (project.findProperty("buildNumber") as String?)?.toIntOrNull() ?: 0
// "owner/repo" whose GitHub Releases the app checks for updates (set by the workflow).
val updateRepo = (project.findProperty("updateRepo") as String?) ?: ""

android {
    namespace = "com.vidsaver.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vidsaver.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 100 + buildNumber
        versionName = "$appVersion.$buildNumber"
        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")
    }

    // ---------------- Signing ----------------
    // Updates only install if every APK is signed with the SAME key, so the key lives in the project
    // (app/keystore/vidsaver-release.jks). Keep a backup of this file — if it changes, installed apps
    // can't update and must be reinstalled.
    signingConfigs {
        create("release") {
            storeFile = file("keystore/vidsaver-release.jks")
            storeType = "pkcs12"
            storePassword = "VldTNN572E4dKj5T9JV0"
            keyAlias = "vidsaver"
            keyPassword = "VldTNN572E4dKj5T9JV0"
        }
    }

    // Separate APK per CPU type (keeps each APK much smaller).
    // Most modern phones need the arm64-v8a one.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a", "x86_64")
            isUniversalApk = false
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Behave like the debug builds that were known to download fine (v1.0).
            isDebuggable = true
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    // Don't let lint warnings stop the release build.
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    // yt-dlp / python / ffmpeg are shipped as native libs and must be extracted.
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    implementation("io.github.junkfood02.youtubedl-android:library:$youtubedlAndroid")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$youtubedlAndroid")

    // AdMob banner ads
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
