/*
 * VidSaver
 * Copyright © 2026 KKsarkar. All rights reserved.
 */

package com.vidsaver.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.vidsaver.app.databinding.ActivityMainBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: DownloadViewModel by viewModels()
    private var adView: AdView? = null
    private var updateDialogShown = false
    /** APK waiting for the user to allow "Install unknown apps". */
    private var pendingInstall: File? = null

    private data class DlJob(val url: String, val audioOnly: Boolean, val maxHeight: Int, val audioKbps: Int)

    private var pending: DlJob? = null
    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val p = pending
            pending = null
            if (granted && p != null) vm.download(p.url, p.audioOnly, p.maxHeight, p.audioKbps)
            else if (!granted) toast("Storage permission is needed to save files")
        }

    private val prefs by lazy { getSharedPreferences("vidsaver", Context.MODE_PRIVATE) }

    // Dropdown choices: label to value (0 = Auto).
    private val videoChoices = listOf(
        0 to "", 2160 to "2160p (4K)", 1440 to "1440p", 1080 to "1080p (Full HD)",
        720 to "720p (HD)", 480 to "480p", 360 to "360p", 240 to "240p",
    )
    private val audioChoices = listOf(0 to "", 320 to "320 kbps", 256 to "256 kbps", 192 to "192 kbps", 128 to "128 kbps")
    private var videoIdx = 0
    private var audioIdx = 0

    /** A shared link waiting for the app to finish starting up before auto-downloading. */
    private var autoStartPending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.urlLayout.setEndIconOnClickListener { pasteFromClipboard() }
        b.downloadBtn.setOnClickListener { startDownload() }
        b.urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { startDownload(); true } else false
        }
        b.cancelBtn.setOnClickListener { vm.cancel() }
        b.updateBtn.setOnClickListener { vm.updateYtDlp() }
        b.detailsBtn.setOnClickListener { showLog() }
        setupQualityPickers()
        b.copyrightText.text = getString(
            R.string.copyright,
            java.util.Calendar.getInstance().get(java.util.Calendar.YEAR),
            BuildConfig.VERSION_NAME,
        )

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }

        setupAds()

        b.appUpdateBtn.isVisible = Updater.isEnabled
        b.appUpdateBtn.setOnClickListener { checkForAppUpdate(manual = true) }
        if (savedInstanceState == null) checkForAppUpdate(manual = false)

        if (savedInstanceState == null) handleShare(intent)
    }

    // ---------- Quality dropdown + auto download ----------

    private fun labels(choices: List<Pair<Int, String>>) =
        choices.map { (v, l) -> if (v == 0) getString(R.string.q_auto) else l }.toTypedArray()

    private fun setupQualityPickers() {
        // Restore the last choices.
        videoIdx = prefs.getInt("video_q_idx", 0).coerceIn(videoChoices.indices)
        audioIdx = prefs.getInt("audio_q_idx", 0).coerceIn(audioChoices.indices)
        b.autoDownloadSwitch.isChecked = prefs.getBoolean("auto_download", true)
        if (prefs.getBoolean("audio_only", false)) b.formatGroup.check(R.id.btnAudio)

        b.autoDownloadSwitch.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("auto_download", on).apply()
        }
        b.qualityDropdown.setOnItemClickListener { _, _, position, _ ->
            if (isAudioSelected()) {
                audioIdx = position
                prefs.edit().putInt("audio_q_idx", position).apply()
            } else {
                videoIdx = position
                prefs.edit().putInt("video_q_idx", position).apply()
            }
        }
        b.formatGroup.addOnButtonCheckedListener { _, id, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            prefs.edit().putBoolean("audio_only", id == R.id.btnAudio).apply()
            showQualityFor(audioOnly = id == R.id.btnAudio)
        }
        showQualityFor(audioOnly = isAudioSelected())
    }

    private fun isAudioSelected() = b.formatGroup.checkedButtonId == R.id.btnAudio

    private fun showQualityFor(audioOnly: Boolean) {
        val items = labels(if (audioOnly) audioChoices else videoChoices)
        b.qualityLayout.hint = getString(if (audioOnly) R.string.audio_quality else R.string.video_quality)
        b.qualityDropdown.setSimpleItems(items)
        b.qualityDropdown.setText(items[if (audioOnly) audioIdx else videoIdx], false)
    }

    /** Starts the download right away if "Auto download" is on (waits if the app is still starting). */
    private fun maybeAutoStart() {
        if (!b.autoDownloadSwitch.isChecked) return
        val s = vm.state.value
        if (s.ready && !s.busy) startDownload() else autoStartPending = true
    }

    // ---------- Ads ----------

    private fun setupAds() {
        lifecycleScope.launch {
            // Google recommends initializing the SDK off the main thread.
            withContext(Dispatchers.IO) { MobileAds.initialize(this@MainActivity) {} }
            loadBanner()
        }
    }

    private fun loadBanner() {
        val metrics = resources.displayMetrics
        // screen width minus the 20dp padding on each side of the layout
        val widthDp = (metrics.widthPixels / metrics.density).toInt() - 40
        val view = AdView(this).apply {
            adUnitId = getString(R.string.admob_banner_id)
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this@MainActivity, widthDp))
        }
        b.adContainer.removeAllViews()
        b.adContainer.addView(view)
        adView = view
        view.loadAd(AdRequest.Builder().build())
    }

    override fun onResume() {
        super.onResume()
        adView?.resume()
        // Back from the "Install unknown apps" setting: continue the update if it's now allowed.
        pendingInstall?.let { apk ->
            if (packageManager.canRequestPackageInstalls() && apk.exists()) {
                pendingInstall = null
                Updater.install(this, apk)
            }
        }
    }

    // ---------- App self-update ----------

    private fun checkForAppUpdate(manual: Boolean) {
        if (!Updater.isEnabled) return
        // Automatic checks at most every 3 hours; the button always checks.
        val now = System.currentTimeMillis()
        if (!manual && now - prefs.getLong("last_app_update_check", 0L) < 3L * 60 * 60 * 1000) return

        lifecycleScope.launch {
            val info = try {
                Updater.check().also { prefs.edit().putLong("last_app_update_check", now).apply() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (manual) toast(getString(R.string.update_check_failed))
                return@launch
            }
            when {
                info != null -> showUpdateDialog(info)
                manual -> toast(getString(R.string.up_to_date, BuildConfig.VERSION_NAME))
            }
        }
    }

    private fun showUpdateDialog(info: UpdateInfo) {
        if (updateDialogShown || isFinishing) return
        updateDialogShown = true
        val msg = buildString {
            if (info.notes.isNotBlank()) append(info.notes.take(1500)).append("\n\n")
            if (info.sizeBytes > 0) append(getString(R.string.update_size, "%.1f".format(info.sizeBytes / 1_048_576.0)))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.update_available_title, info.versionName))
            .setMessage(msg.trim())
            .setPositiveButton(R.string.update_now) { _, _ -> downloadAndInstall(info) }
            .setNegativeButton(R.string.later, null)
            .setOnDismissListener { updateDialogShown = false }
            .show()
    }

    private fun downloadAndInstall(info: UpdateInfo) {
        val pad = (24 * resources.displayMetrics.density).toInt()
        val bar = LinearProgressIndicator(this).apply {
            isIndeterminate = true
            setPadding(pad, pad / 2, pad, 0)
        }
        var dialog: AlertDialog? = null
        val job = lifecycleScope.launch {
            try {
                val apk = Updater.download(this@MainActivity, info) { pct ->
                    if (pct in 0..100) {
                        if (bar.isIndeterminate) {
                            bar.visibility = View.INVISIBLE
                            bar.isIndeterminate = false
                            bar.visibility = View.VISIBLE
                        }
                        bar.setProgressCompat(pct, true)
                        dialog?.setTitle(getString(R.string.downloading_update) + " $pct%")
                    }
                }
                dialog?.dismiss()
                if (Updater.ensureInstallPermission(this@MainActivity)) {
                    Updater.install(this@MainActivity, apk)
                } else {
                    pendingInstall = apk
                    toast(getString(R.string.allow_install))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                dialog?.dismiss()
                toast(getString(R.string.update_download_failed))
            }
        }
        dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.downloading_update)
            .setView(bar)
            .setCancelable(false)
            .setNegativeButton(R.string.cancel) { _, _ -> job.cancel() }
            .show()
    }

    override fun onPause() {
        adView?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        adView?.destroy()
        adView = null
        super.onDestroy()
    }

    // ---------- Error details ----------

    private fun showLog() {
        val log = vm.state.value.log.ifEmpty { "—" }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val text = TextView(this).apply {
            this.text = log
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(pad, pad, pad, pad)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(text) }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.details_title)
            .setView(scroll)
            .setPositiveButton(R.string.close, null)
            .setNeutralButton(R.string.copy) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("VidSaver log", log))
                toast("Copied")
            }
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val url = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()) ?: return
        b.urlInput.setText(url)
        if (b.autoDownloadSwitch.isChecked) maybeAutoStart()
        else toast("Link added — choose Video or Audio and tap Download")
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        val url = text?.let { extractUrl(it) }
        if (url != null) {
            b.urlInput.setText(url)
            maybeAutoStart()
        } else {
            toast("No link found in clipboard")
        }
    }

    private fun startDownload() {
        val url = extractUrl(b.urlInput.text?.toString().orEmpty())
        if (url == null) {
            b.urlLayout.error = "Enter a valid link (https://…)"
            return
        }
        b.urlLayout.error = null
        hideKeyboard()
        val job = DlJob(
            url = url,
            audioOnly = isAudioSelected(),
            maxHeight = videoChoices[videoIdx].first,
            audioKbps = audioChoices[audioIdx].first,
        )

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending = job
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        vm.download(job.url, job.audioOnly, job.maxHeight, job.audioKbps)
    }

    private fun render(s: UiState) {
        b.downloadBtn.isEnabled = s.ready && !s.busy
        b.updateBtn.isEnabled = s.ready && !s.busy
        b.cancelBtn.isVisible = s.canCancel

        val showBar = s.busy
        val wantIndeterminate = s.progress < 0
        if (b.progress.isIndeterminate != wantIndeterminate) {
            // Material requires the bar to be hidden while switching modes.
            b.progress.visibility = View.INVISIBLE
            b.progress.isIndeterminate = wantIndeterminate
        }
        if (!wantIndeterminate) b.progress.setProgressCompat(s.progress, true)
        b.progress.visibility = if (showBar) View.VISIBLE else View.INVISIBLE

        b.statusText.text = s.status
        if (autoStartPending && s.ready && !s.busy) {
            autoStartPending = false
            b.root.post { startDownload() }
        }
        b.detailsBtn.isVisible = s.failed && !s.busy
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(b.urlInput.windowToken, 0)
        b.urlInput.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private val URL_REGEX = Regex("""https?://\S+""")
        fun extractUrl(text: String): String? =
            URL_REGEX.find(text)?.value?.trimEnd('.', ',', ')', ']', '"', '\'')
    }
}
