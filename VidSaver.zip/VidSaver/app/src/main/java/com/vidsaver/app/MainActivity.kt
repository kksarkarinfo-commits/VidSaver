package com.vidsaver.app

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.vidsaver.app.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: DownloadViewModel by viewModels()

    private var pending: Pair<String, Boolean>? = null
    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val p = pending
            pending = null
            if (granted && p != null) vm.download(p.first, p.second)
            else if (!granted) toast("Storage permission is needed to save files")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.urlLayout.setEndIconOnClickListener { pasteFromClipboard() }
        b.downloadBtn.setOnClickListener { startDownload() }
        b.urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { startDownload(); true } else false
        }
        b.cancelBtn.setOnClickListener { vm.cancel() }
        b.updateBtn.setOnClickListener { vm.updateYtDlp() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }

        if (savedInstanceState == null) handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val url = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()) ?: return
        b.urlInput.setText(url)
        toast("Link added — choose Video or Audio and tap Download")
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        val url = text?.let { extractUrl(it) }
        if (url != null) b.urlInput.setText(url) else toast("No link found in clipboard")
    }

    private fun startDownload() {
        val url = extractUrl(b.urlInput.text?.toString().orEmpty())
        if (url == null) {
            b.urlLayout.error = "Enter a valid link (https://…)"
            return
        }
        b.urlLayout.error = null
        hideKeyboard()
        val audioOnly = b.formatGroup.checkedButtonId == R.id.btnAudio

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending = url to audioOnly
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        vm.download(url, audioOnly)
    }

    private fun render(s: UiState) {
        b.downloadBtn.isEnabled = s.ready && !s.busy
        b.updateBtn.isEnabled = s.ready && !s.busy
        b.cancelBtn.isVisible = s.canCancel

        val showBar = s.busy
        val wantIndeterminate = s.progress < 0
        if (b.progress.isIndeterminate != wantIndeterminate) {
            // Material requires the bar to be hidden while switching modes.
            b.progress.visibility = View.INVISIBLE
            b.progress.isIndeterminate = wantIndeterminate
        }
        if (!wantIndeterminate) b.progress.setProgressCompat(s.progress, true)
        b.progress.visibility = if (showBar) View.VISIBLE else View.INVISIBLE

        b.statusText.text = s.status
        b.logText.text = s.log.ifEmpty { "—" }.lines().takeLast(14).joinToString("\n")
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(b.urlInput.windowToken, 0)
        b.urlInput.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private val URL_REGEX = Regex("""https?://\S+""")
        fun extractUrl(text: String): String? =
            URL_REGEX.find(text)?.value?.trimEnd('.', ',', ')', ']', '"', '\'')
    }
}
