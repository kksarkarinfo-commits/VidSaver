package com.vidsaver.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class UiState(
    val ready: Boolean = false,
    val busy: Boolean = false,
    val canCancel: Boolean = false,
    /** -1 = unknown (indeterminate bar), 0..100 = percent */
    val progress: Int = -1,
    val status: String = "",
    val log: String = "",
)

class DownloadViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState(busy = true, status = "Starting up… (first launch takes a moment)"))
    val state: StateFlow<UiState> = _state

    private val processId = "vidsaver-download"
    private var job: Job? = null
    @Volatile private var cancelled = false

    private val ctx: Context get() = getApplication()
    private val prefs get() = ctx.getSharedPreferences("vidsaver", Context.MODE_PRIVATE)

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(ctx)
                FFmpeg.getInstance().init(ctx)
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, status = "Setup failed: ${e.message}") }
                return@launch
            }
            // Sites change often; a fresh yt-dlp keeps downloads working. Auto-update at most once a day.
            val last = prefs.getLong("last_update", 0L)
            if (System.currentTimeMillis() - last > 24L * 60 * 60 * 1000) {
                runUpdate(silent = true)
            }
            _state.update { it.copy(ready = true, busy = false, status = "Ready. Paste or share a video link.") }
        }
    }

    fun download(url: String, audioOnly: Boolean) {
        if (job?.isActive == true || !_state.value.ready) return
        cancelled = false
        job = viewModelScope.launch(Dispatchers.IO) {
            val tmp = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
            _state.update {
                it.copy(busy = true, canCancel = true, progress = -1, status = "Getting video info…", log = "")
            }

            val request = YoutubeDLRequest(url).apply {
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("--newline")
                addOption("-o", tmp.absolutePath + "/%(title).80B [%(id)s].%(ext)s")
                if (audioOnly) {
                    addOption("-f", "ba/b")
                    addOption("-x")
                    addOption("--audio-format", "mp3")
                    addOption("--audio-quality", "0")
                } else {
                    addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b")
                    addOption("--merge-output-format", "mp4")
                }
                addYoutubeJsOptions(this)
            }

            try {
                YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
                    _state.update { s ->
                        val pct = progress.toInt()
                        val status = when {
                            line.contains("[Merger]") || line.contains("[ExtractAudio]") -> "Processing file…"
                            pct in 0..100 -> "Downloading $pct%" + if (eta > 0) " • ${eta}s left" else ""
                            else -> s.status
                        }
                        s.copy(progress = if (pct in 0..100) pct else s.progress, status = status, log = appendLog(s.log, line))
                    }
                }

                val files = tmp.listFiles()
                    ?.filter { it.isFile && it.length() > 0 && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                    .orEmpty()
                if (files.isEmpty()) throw IllegalStateException("No file was produced")

                _state.update { it.copy(canCancel = false, progress = -1, status = "Saving…") }
                val saved = files.map { Storage.saveToDownloads(ctx, it) }
                _state.update {
                    it.copy(busy = false, canCancel = false, progress = 100,
                        status = "✓ Saved to " + saved.joinToString("\n"))
                }
            } catch (e: Exception) {
                val msg = if (cancelled) "Cancelled." else friendlyError(e)
                _state.update {
                    it.copy(busy = false, canCancel = false, progress = 0, status = msg,
                        log = if (cancelled) it.log else appendLog(it.log, e.message ?: e.toString()))
                }
            } finally {
                tmp.deleteRecursively()
            }
        }
    }

    fun cancel() {
        cancelled = true
        try { YoutubeDL.getInstance().destroyProcessById(processId) } catch (_: Exception) {}
        job?.cancel()
        _state.update { it.copy(busy = false, canCancel = false, progress = 0, status = "Cancelled.") }
    }

    fun updateYtDlp() {
        if (_state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) { runUpdate(silent = false) }
    }

    private fun runUpdate(silent: Boolean) {
        _state.update { it.copy(busy = true, progress = -1, status = "Updating yt-dlp…") }
        try {
            val result = YoutubeDL.getInstance().updateYoutubeDL(ctx)
            prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
            val version = YoutubeDL.getInstance().version(ctx) ?: "?"
            if (!silent) {
                _state.update { it.copy(busy = false, progress = 0, status = "yt-dlp $version ($result)") }
            }
        } catch (e: Exception) {
            if (!silent) {
                _state.update { it.copy(busy = false, progress = 0, status = "Update failed: ${e.message}") }
            }
        }
        if (silent) _state.update { it.copy(busy = false) }
    }

    /**
     * Newer yt-dlp needs a JavaScript runtime for full YouTube support.
     * youtubedl-android 0.18.1+ ships QuickJS; point yt-dlp at it if we can find it.
     */
    private fun addYoutubeJsOptions(request: YoutubeDLRequest) {
        val version = try { YoutubeDL.getInstance().version(ctx) } catch (_: Exception) { null } ?: return
        if (version < "2025.11.12") return // older yt-dlp doesn't know these options
        findQuickJs()?.let { request.addOption("--js-runtimes", "quickjs:${it.absolutePath}") }
        request.addOption("--remote-components", "ejs:github")
    }

    private fun findQuickJs(): File? {
        val candidates = sequenceOf(File(ctx.applicationInfo.nativeLibraryDir), ctx.noBackupFilesDir)
        for (root in candidates) {
            val hit = root.walkTopDown().maxDepth(5).firstOrNull { f ->
                f.isFile && f.name.lowercase().let { n ->
                    (n == "qjs" || n == "libqjs.so" || n == "quickjs" || n == "libquickjs.so")
                }
            }
            if (hit != null) {
                hit.setExecutable(true)
                return hit
            }
        }
        return null
    }

    private fun friendlyError(e: Exception): String {
        val m = (e.message ?: "").lowercase()
        return when {
            "login" in m || "cookies" in m || "private" in m ->
                "This video needs a login or is private, so it can't be downloaded."
            "unsupported url" in m -> "This link isn't supported."
            "unable to resolve host" in m || "network" in m || "timed out" in m ->
                "Network problem. Check your internet and try again."
            else -> "Download failed. Try \"Update yt-dlp\" and retry. (see log)"
        }
    }

    private fun appendLog(log: String, line: String): String {
        if (line.isBlank()) return log
        val next = if (log.isEmpty()) line else "$log\n$line"
        return if (next.length > 6000) next.takeLast(6000) else next
    }
}
