/*
 * VidSaver
 * Copyright © 2026 KKsarkar. All rights reserved.
 */

package com.vidsaver.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class UiState(
    val ready: Boolean = false,
    val busy: Boolean = false,
    val canCancel: Boolean = false,
    /** -1 = unknown (indeterminate bar), 0..100 = percent */
    val progress: Int = -1,
    val status: String = "",
    val log: String = "",
    /** true after a failed download, so the UI can offer a "Details" button with the log */
    val failed: Boolean = false,
)

class DownloadViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(UiState(busy = true, status = "Starting up… (first launch takes a moment)"))
    val state: StateFlow<UiState> = _state

    private val processId = "vidsaver-download"
    private var job: Job? = null
    @Volatile private var cancelled = false

    private val ctx: Context get() = getApplication()
    private val prefs get() = ctx.getSharedPreferences("vidsaver", Context.MODE_PRIVATE)

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(ctx)
                FFmpeg.getInstance().init(ctx)
                try { installPlugins() } catch (_: Exception) { /* only Threads would be affected */ }
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, status = "Setup failed: ${e.message}") }
                return@launch
            }
            // Sites change often; a fresh yt-dlp keeps downloads working. Auto-update at most once a day.
            val last = prefs.getLong("last_update", 0L)
            if (System.currentTimeMillis() - last > 24L * 60 * 60 * 1000) {
                runUpdate(silent = true)
            }
            _state.update { it.copy(ready = true, busy = false, status = "Ready. Paste or share a video link.") }
        }
    }

    /**
     * @param maxHeight video resolution limit (e.g. 720). 0 = Auto (best, same settings as v1.0).
     * @param audioKbps MP3 bitrate (320, 256, 192, 128). 0 = Auto (best).
     *
     * If the first try fails, it automatically tries once more with the simplest possible settings.
     */
    fun download(url: String, audioOnly: Boolean, maxHeight: Int, audioKbps: Int) {
        if (job?.isActive == true || !_state.value.ready) return
        cancelled = false
        job = viewModelScope.launch(Dispatchers.IO) {
            val tmp = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
            _state.update {
                it.copy(busy = true, canCancel = true, progress = -1, status = "Getting video info…", log = "", failed = false)
            }
            try {
                var lastError: Exception? = null
                for (attempt in 1..2) {
                    if (cancelled) break
                    tmp.listFiles()?.forEach { it.deleteRecursively() }
                    val simple = attempt == 2
                    if (simple) {
                        _state.update { it.copy(progress = -1, status = "Retrying with basic settings…",
                            log = appendLog(it.log, "---- retry with basic settings ----")) }
                    }
                    try {
                        runYtDlp(buildRequest(url, tmp, audioOnly, maxHeight, audioKbps, simple))
                        val files = tmp.listFiles()
                            ?.filter { it.isFile && it.length() > 0 && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                            .orEmpty()
                        if (files.isEmpty()) throw IllegalStateException("No file was produced")

                        _state.update { it.copy(canCancel = false, progress = -1, status = "Saving…") }
                        val saved = files.map { Storage.saveToDownloads(ctx, it) }
                        _state.update {
                            it.copy(busy = false, canCancel = false, progress = 100,
                                status = "✓ Saved to " + saved.joinToString("\n"))
                        }
                        return@launch
                    } catch (e: Exception) {
                        if (cancelled || e is kotlinx.coroutines.CancellationException) throw e
                        lastError = e
                        _state.update { it.copy(log = appendLog(it.log, "ERROR: " + (e.message ?: e.toString()))) }
                        if (!worthRetrying(e)) break
                    }
                }
                throw lastError ?: IllegalStateException("Download failed")
            } catch (e: Exception) {
                val msg = if (cancelled) "Cancelled." else friendlyError(e)
                _state.update {
                    it.copy(busy = false, canCancel = false, progress = 0, status = msg, failed = !cancelled)
                }
            } finally {
                tmp.deleteRecursively()
            }
        }
    }

    private fun buildRequest(
        url: String, tmp: File, audioOnly: Boolean, maxHeight: Int, audioKbps: Int, simple: Boolean,
    ) = YoutubeDLRequest(url).apply {
        addOption("--no-playlist")
        addOption("--no-mtime")
        addOption("--newline")
        addOption("-o", tmp.absolutePath + "/%(title).80B [%(id)s].%(ext)s")
        when {
            audioOnly -> {
                addOption("-f", if (simple) "b" else "ba/b")
                addOption("-x")
                addOption("--audio-format", "mp3")
                addOption("--audio-quality", if (audioKbps > 0) "${audioKbps}K" else "0")
            }
            simple -> {
                // Basic fallback: let yt-dlp pick whatever works.
                addOption("-f", "bv*+ba/b")
            }
            maxHeight > 0 -> {
                // Highest resolution not above the chosen one (short side, so vertical videos work too),
                // preferring MP4/M4A so the file plays everywhere.
                addOption("-f", "bv*+ba/b")
                addOption("-S", "res:$maxHeight,ext:mp4:m4a")
                addOption("--merge-output-format", "mp4")
            }
            else -> {
                // Auto: exactly the settings of v1.0 (best MP4, falls back to anything).
                addOption("-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b")
                addOption("--merge-output-format", "mp4")
            }
        }
        if (!simple) {
            addYoutubeJsOptions(this)
            if (isThreads(url)) addPluginOptions(this)
        }
    }

    private fun runYtDlp(request: YoutubeDLRequest) {
        YoutubeDL.getInstance().execute(request, processId) { progress, eta, line ->
            _state.update { s ->
                val pct = progress.toInt()
                val status = when {
                    line.contains("[Merger]") || line.contains("[ExtractAudio]") -> "Processing file…"
                    pct in 0..100 -> "Downloading $pct%" + if (eta > 0) " • ${eta}s left" else ""
                    else -> s.status
                }
                s.copy(progress = if (pct in 0..100) pct else s.progress, status = status, log = appendLog(s.log, line))
            }
        }
    }

    private fun isThreads(url: String): Boolean {
        val host = try { java.net.URI(url).host.orEmpty().lowercase() } catch (_: Exception) { "" }
        return host == "threads.net" || host.endsWith(".threads.net") ||
            host == "threads.com" || host.endsWith(".threads.com")
    }

    /** No point retrying when the link itself is the problem. */
    private fun worthRetrying(e: Exception): Boolean {
        val m = (e.message ?: "").lowercase()
        return !("unsupported url" in m || "private" in m || "unable to resolve host" in m ||
            "no address associated" in m || "404" in m)
    }

    fun cancel() {
        cancelled = true
        try { YoutubeDL.getInstance().destroyProcessById(processId) } catch (_: Exception) {}
        job?.cancel()
        _state.update { it.copy(busy = false, canCancel = false, progress = 0, status = "Cancelled.") }
    }

    fun updateYtDlp() {
        if (_state.value.busy) return
        viewModelScope.launch(Dispatchers.IO) { runUpdate(silent = false) }
    }

    private fun runUpdate(silent: Boolean) {
        _state.update { it.copy(busy = true, progress = -1, status = "Updating yt-dlp…") }
        try {
            val result = YoutubeDL.getInstance().updateYoutubeDL(ctx)
            prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
            val version = YoutubeDL.getInstance().version(ctx) ?: "?"
            if (!silent) {
                _state.update { it.copy(busy = false, progress = 0, status = "yt-dlp $version ($result)") }
            }
        } catch (e: Exception) {
            if (!silent) {
                _state.update { it.copy(busy = false, progress = 0, status = "Update failed: ${e.message}") }
            }
        }
        if (silent) _state.update { it.copy(busy = false) }
    }

    /**
     * youtubedl-android already passes its bundled QuickJS (--js-runtimes) on every run.
     * Newer yt-dlp also needs the "EJS" solver scripts for YouTube; allow fetching them if missing.
     */
    private fun addYoutubeJsOptions(request: YoutubeDLRequest) {
        val version = try { YoutubeDL.getInstance().version(ctx) } catch (_: Exception) { null } ?: return
        if (version < "2025.11.12") return // older yt-dlp doesn't know this option
        request.addOption("--remote-components", "ejs:github")
    }

    /**
     * yt-dlp has no built-in Threads extractor. We ship the public-domain
     * "yt-dlp-threads" plugin in assets and copy it to app storage, laid out the way
     * `--plugin-dirs` expects: DIR / PACKAGE / yt_dlp_plugins / extractor / threads.py
     */
    private val pluginRoot: File get() = File(ctx.filesDir, "ytdlp-plugins")

    private fun installPlugins() {
        val rel = "vidsaver/yt_dlp_plugins/extractor"
        val outDir = File(pluginRoot, rel).apply { mkdirs() }
        val names = ctx.assets.list("ytdlp-plugins/$rel").orEmpty()
        for (name in names) {
            ctx.assets.open("ytdlp-plugins/$rel/$name").use { input ->
                File(outDir, name).outputStream().use { input.copyTo(it) }
            }
        }
    }

    private fun addPluginOptions(request: YoutubeDLRequest) {
        val version = try { YoutubeDL.getInstance().version(ctx) } catch (_: Exception) { null } ?: return
        if (version < "2024.10.22") return // --plugin-dirs was added in this release
        if (pluginRoot.isDirectory) request.addOption("--plugin-dirs", pluginRoot.absolutePath)
    }

    private fun friendlyError(e: Exception): String {
        val raw = e.message ?: e.toString()
        val m = raw.lowercase()
        val hint = when {
            "login" in m || "cookies" in m || "private" in m || "rate-limit" in m ->
                "This video is private or the site blocked it. Try again later or another link."
            "unsupported url" in m -> "This link isn't supported. Tap \"Update yt-dlp\" and try again."
            "unable to resolve host" in m || "network" in m || "timed out" in m || "no address associated" in m ->
                "Network problem. Check your internet and try again."
            else -> "Download failed. Tap \"Update yt-dlp\" and try again."
        }
        // Show the real error line too, so it can be reported.
        val errLine = raw.lineSequence().map { it.trim() }.lastOrNull { it.startsWith("ERROR") }
            ?: raw.lineSequence().map { it.trim() }.lastOrNull { it.isNotEmpty() } ?: ""
        return if (errLine.isEmpty()) hint else "$hint\n\n${errLine.take(300)}"
    }

    private fun appendLog(log: String, line: String): String {
        if (line.isBlank()) return log
        val next = if (log.isEmpty()) line else "$log\n$line"
        return if (next.length > 6000) next.takeLast(6000) else next
    }
}
