/*
 * VidSaver
 * Copyright © 2026 KKsarkar. All rights reserved.
 */

package com.vidsaver.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** A newer release found on GitHub. */
data class UpdateInfo(
    val versionName: String,
    val notes: String,
    val apkUrl: String,
    val apkName: String,
    val sizeBytes: Long,
)

/**
 * Self-update from the GitHub Releases of the repo the app was built from
 * (BuildConfig.UPDATE_REPO, filled in by the GitHub Actions workflow).
 */
object Updater {

    val isEnabled: Boolean get() = BuildConfig.UPDATE_REPO.isNotBlank()

    /** Returns the newer release, or null when the app is already up to date. Throws on network errors. */
    suspend fun check(): UpdateInfo? = withContext(Dispatchers.IO) {
        if (!isEnabled) return@withContext null
        val url = URL("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/latest")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 15_000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "VidSaver-Android")
        }
        try {
            if (conn.responseCode == 404) return@withContext null // no release yet
            if (conn.responseCode != 200) throw IOException("GitHub returned HTTP ${conn.responseCode}")
            val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val latest = json.optString("tag_name").removePrefix("v").removePrefix("V")
            if (latest.isBlank() || !isNewer(latest, BuildConfig.VERSION_NAME)) return@withContext null

            val assets = json.optJSONArray("assets") ?: return@withContext null
            val apks = (0 until assets.length()).map { assets.getJSONObject(it) }
                .filter { it.optString("name").endsWith(".apk", ignoreCase = true) }
            val apk = pickApkForThisPhone(apks) ?: return@withContext null

            UpdateInfo(
                versionName = latest,
                notes = json.optString("body").trim(),
                apkUrl = apk.getString("browser_download_url"),
                apkName = apk.getString("name"),
                sizeBytes = apk.optLong("size", -1),
            )
        } finally {
            conn.disconnect()
        }
    }

    /** "1.3.12" > "1.3.9" — compares number by number. */
    fun isNewer(candidate: String, current: String): Boolean {
        fun parts(v: String) = v.split('.', '-', '_').map { p -> p.takeWhile { it.isDigit() }.toIntOrNull() ?: 0 }
        val a = parts(candidate)
        val b = parts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** Release APKs are split per CPU type (arm64-v8a, armeabi-v7a, x86_64); pick the one this phone needs. */
    private fun pickApkForThisPhone(apks: List<JSONObject>): JSONObject? {
        for (abi in Build.SUPPORTED_ABIS) {
            apks.firstOrNull { it.optString("name").contains(abi, ignoreCase = true) }?.let { return it }
        }
        return apks.firstOrNull { it.optString("name").contains("universal", ignoreCase = true) }
            ?: apks.singleOrNull()
    }

    /** Downloads the APK into the app cache. [onProgress] gets 0..100, or -1 when the size is unknown. */
    suspend fun download(ctx: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File =
        withContext(Dispatchers.IO) {
            val dir = File(ctx.cacheDir, "updates").apply { deleteRecursively(); mkdirs() }
            val out = File(dir, "VidSaver-${info.versionName}.apk")
            val conn = (URL(info.apkUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 30_000
                instanceFollowRedirects = true // GitHub redirects to its file CDN
                setRequestProperty("User-Agent", "VidSaver-Android")
            }
            try {
                if (conn.responseCode !in 200..299) throw IOException("Download failed (HTTP ${conn.responseCode})")
                val total = conn.contentLengthLong.takeIf { it > 0 } ?: info.sizeBytes
                conn.inputStream.use { input ->
                    out.outputStream().use { output ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var lastPct = -2
                        while (true) {
                            ensureActive() // stops when the user taps Cancel
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            val pct = if (total > 0) ((done * 100) / total).toInt() else -1
                            if (pct != lastPct) {
                                lastPct = pct
                                withContext(Dispatchers.Main) { onProgress(pct) }
                            }
                        }
                    }
                }
                out
            } catch (e: Exception) {
                out.delete()
                throw e
            } finally {
                conn.disconnect()
            }
        }

    /** True if Android lets this app open the installer; otherwise sends the user to the setting. */
    fun ensureInstallPermission(activity: Activity): Boolean {
        if (activity.packageManager.canRequestPackageInstalls()) return true
        activity.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
        )
        return false
    }

    /** Opens Android's installer for the downloaded APK. */
    fun install(activity: Activity, apk: File) {
        val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", apk)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        activity.startActivity(intent)
    }
}
