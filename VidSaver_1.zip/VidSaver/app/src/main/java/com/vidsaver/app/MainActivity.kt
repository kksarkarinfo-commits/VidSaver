/*
 * VidSaver
 * Copyright © 2026 KKsarkar. All rights reserved.
 */

package com.vidsaver.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import androidx.appcompat.app.AlertDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.vidsaver.app.databinding.ActivityMainBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: DownloadViewModel by viewModels()
    private var adView: AdView? = null
    private var updateDialogShown = false
    /** APK waiting for the user to allow "Install unknown apps". */
    private var pendingInstall: File? = null

    private data class DlJob(val url: String, val audioOnly: Boolean, val maxHeight: Int, val audioKbps: Int)

    private var pending: DlJob? = null
    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val p = pending
            pending = null
            if (granted && p != null) vm.download(p.url, p.audioOnly, p.maxHeight, p.audioKbps)
            else if (!granted) toast("Storage permission is needed to save files")
        }

    private val prefs by lazy { getSharedPreferences("vidsaver", Context.MODE_PRIVATE) }

    private val heightByChip = mapOf(
        R.id.q_best to 0, R.id.q_1080 to 1080, R.id.q_720 to 720, R.id.q_480 to 480, R.id.q_360 to 360,
    )
    private val kbpsByChip = mapOf(
        R.id.b_320 to 320, R.id.b_256 to 256, R.id.b_192 to 192, R.id.b_128 to 128,
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.urlLayout.setEndIconOnClickListener { pasteFromClipboard() }
        b.downloadBtn.setOnClickListener { startDownload() }
        b.urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { startDownload(); true } else false
        }
        b.cancelBtn.setOnClickListener { vm.cancel() }
        b.updateBtn.setOnClickListener { vm.updateYtDlp() }
        b.detailsBtn.setOnClickListener { showLog() }
        setupQualityPickers()
        b.copyrightText.text = getString(
            R.string.copyright,
            java.util.Calendar.getInstance().get(java.util.Calendar.YEAR),
            BuildConfig.VERSION_NAME,
        )

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }

        setupAds()

        b.signInBtn.setOnClickListener { showSignInDialog() }
        b.appUpdateBtn.isVisible = Updater.isEnabled
        b.appUpdateBtn.setOnClickListener { checkForAppUpdate(manual = true) }
        if (savedInstanceState == null) checkForAppUpdate(manual = false)

        if (savedInstanceState == null) handleShare(intent)
    }

    // ---------- Quality pickers ----------

    private fun setupQualityPickers() {
        // Restore the last choices.
        val savedHeight = prefs.getInt("max_height", 0)
        val savedKbps = prefs.getInt("audio_kbps", 320)
        heightByChip.entries.firstOrNull { it.value == savedHeight }?.let { b.videoQualityGroup.check(it.key) }
        kbpsByChip.entries.firstOrNull { it.value == savedKbps }?.let { b.audioQualityGroup.check(it.key) }
        if (prefs.getBoolean("audio_only", false)) b.formatGroup.check(R.id.btnAudio)

        b.videoQualityGroup.setOnCheckedStateChangeListener { _, ids ->
            ids.firstOrNull()?.let { prefs.edit().putInt("max_height", heightByChip[it] ?: 0).apply() }
        }
        b.audioQualityGroup.setOnCheckedStateChangeListener { _, ids ->
            ids.firstOrNull()?.let { prefs.edit().putInt("audio_kbps", kbpsByChip[it] ?: 320).apply() }
        }
        b.formatGroup.addOnButtonCheckedListener { _, id, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            prefs.edit().putBoolean("audio_only", id == R.id.btnAudio).apply()
            showQualityFor(audioOnly = id == R.id.btnAudio)
        }
        showQualityFor(audioOnly = b.formatGroup.checkedButtonId == R.id.btnAudio)
    }

    private fun showQualityFor(audioOnly: Boolean) {
        b.videoQualityGroup.isVisible = !audioOnly
        b.audioQualityGroup.isVisible = audioOnly
        b.qualityLabel.setText(if (audioOnly) R.string.audio_quality else R.string.video_quality)
    }

    // ---------- Ads ----------

    private fun setupAds() {
        lifecycleScope.launch {
            // Google recommends initializing the SDK off the main thread.
            withContext(Dispatchers.IO) { MobileAds.initialize(this@MainActivity) {} }
            loadBanner()
        }
    }

    private fun loadBanner() {
        val metrics = resources.displayMetrics
        // screen width minus the 20dp padding on each side of the layout
        val widthDp = (metrics.widthPixels / metrics.density).toInt() - 40
        val view = AdView(this).apply {
            adUnitId = getString(R.string.admob_banner_id)
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this@MainActivity, widthDp))
        }
        b.adContainer.removeAllViews()
        b.adContainer.addView(view)
        adView = view
        view.loadAd(AdRequest.Builder().build())
    }

    override fun onResume() {
        super.onResume()
        adView?.resume()
        // Back from the "Install unknown apps" setting: continue the update if it's now allowed.
        pendingInstall?.let { apk ->
            if (packageManager.canRequestPackageInstalls() && apk.exists()) {
                pendingInstall = null
                Updater.install(this, apk)
            }
        }
    }

    // ---------- Sign in (cookies for login-only videos) ----------

    private fun showSignInDialog() {
        val sites = CookieStore.sites
        val labels = sites.map { s ->
            if (CookieStore.isSignedIn(this, s)) getString(R.string.signed_in_mark, s.name) else s.name
        }.toTypedArray<CharSequence>()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.sign_in_title)
            .setItems(labels) { _, which ->
                val site = sites[which]
                if (CookieStore.isSignedIn(this, site)) {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(site.name)
                        .setPositiveButton(R.string.sign_out) { _, _ ->
                            CookieStore.signOut(this, site)
                            toast(getString(R.string.signed_out, site.name))
                        }
                        .setNeutralButton(getString(R.string.sign_in_to, site.name)) { _, _ -> openLogin(site) }
                        .setNegativeButton(R.string.close, null)
                        .show()
                } else {
                    openLogin(site)
                }
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun openLogin(site: LoginSite) {
        startActivity(Intent(this, LoginActivity::class.java).putExtra(LoginActivity.EXTRA_DOMAIN, site.domain))
    }

    // ---------- App self-update ----------

    private fun checkForAppUpdate(manual: Boolean) {
        if (!Updater.isEnabled) return
        // Automatic checks at most every 3 hours; the button always checks.
        val now = System.currentTimeMillis()
        if (!manual && now - prefs.getLong("last_app_update_check", 0L) < 3L * 60 * 60 * 1000) return

        lifecycleScope.launch {
            val info = try {
                Updater.check().also { prefs.edit().putLong("last_app_update_check", now).apply() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (manual) toast(getString(R.string.update_check_failed))
                return@launch
            }
            when {
                info != null -> showUpdateDialog(info)
                manual -> toast(getString(R.string.up_to_date, BuildConfig.VERSION_NAME))
            }
        }
    }

    private fun showUpdateDialog(info: UpdateInfo) {
        if (updateDialogShown || isFinishing) return
        updateDialogShown = true
        val msg = buildString {
            if (info.notes.isNotBlank()) append(info.notes.take(1500)).append("\n\n")
            if (info.sizeBytes > 0) append(getString(R.string.update_size, "%.1f".format(info.sizeBytes / 1_048_576.0)))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.update_available_title, info.versionName))
            .setMessage(msg.trim())
            .setPositiveButton(R.string.update_now) { _, _ -> downloadAndInstall(info) }
            .setNegativeButton(R.string.later, null)
            .setOnDismissListener { updateDialogShown = false }
            .show()
    }

    private fun downloadAndInstall(info: UpdateInfo) {
        val pad = (24 * resources.displayMetrics.density).toInt()
        val bar = LinearProgressIndicator(this).apply {
            isIndeterminate = true
            setPadding(pad, pad / 2, pad, 0)
        }
        var dialog: AlertDialog? = null
        val job = lifecycleScope.launch {
            try {
                val apk = Updater.download(this@MainActivity, info) { pct ->
                    if (pct in 0..100) {
                        if (bar.isIndeterminate) {
                            bar.visibility = View.INVISIBLE
                            bar.isIndeterminate = false
                            bar.visibility = View.VISIBLE
                        }
                        bar.setProgressCompat(pct, true)
                        dialog?.setTitle(getString(R.string.downloading_update) + " $pct%")
                    }
                }
                dialog?.dismiss()
                if (Updater.ensureInstallPermission(this@MainActivity)) {
                    Updater.install(this@MainActivity, apk)
                } else {
                    pendingInstall = apk
                    toast(getString(R.string.allow_install))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                dialog?.dismiss()
                toast(getString(R.string.update_download_failed))
            }
        }
        dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.downloading_update)
            .setView(bar)
            .setCancelable(false)
            .setNegativeButton(R.string.cancel) { _, _ -> job.cancel() }
            .show()
    }

    override fun onPause() {
        adView?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        adView?.destroy()
        adView = null
        super.onDestroy()
    }

    // ---------- Error details ----------

    private fun showLog() {
        val log = vm.state.value.log.ifEmpty { "—" }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val text = TextView(this).apply {
            this.text = log
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(pad, pad, pad, pad)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(text) }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.details_title)
            .setView(scroll)
            .setPositiveButton(R.string.close, null)
            .setNeutralButton(R.string.copy) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("VidSaver log", log))
                toast("Copied")
            }
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val url = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()) ?: return
        b.urlInput.setText(url)
        toast("Link added — choose Video or Audio and tap Download")
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        val url = text?.let { extractUrl(it) }
        if (url != null) b.urlInput.setText(url) else toast("No link found in clipboard")
    }

    private fun startDownload() {
        val url = extractUrl(b.urlInput.text?.toString().orEmpty())
        if (url == null) {
            b.urlLayout.error = "Enter a valid link (https://…)"
            return
        }
        b.urlLayout.error = null
        hideKeyboard()
        val job = DlJob(
            url = url,
            audioOnly = b.formatGroup.checkedButtonId == R.id.btnAudio,
            maxHeight = heightByChip[b.videoQualityGroup.checkedChipId] ?: 0,
            audioKbps = kbpsByChip[b.audioQualityGroup.checkedChipId] ?: 320,
        )

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending = job
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        vm.download(job.url, job.audioOnly, job.maxHeight, job.audioKbps)
    }

    private fun render(s: UiState) {
        b.downloadBtn.isEnabled = s.ready && !s.busy
        b.updateBtn.isEnabled = s.ready && !s.busy
        b.cancelBtn.isVisible = s.canCancel

        val showBar = s.busy
        val wantIndeterminate = s.progress < 0
        if (b.progress.isIndeterminate != wantIndeterminate) {
            // Material requires the bar to be hidden while switching modes.
            b.progress.visibility = View.INVISIBLE
            b.progress.isIndeterminate = wantIndeterminate
        }
        if (!wantIndeterminate) b.progress.setProgressCompat(s.progress, true)
        b.progress.visibility = if (showBar) View.VISIBLE else View.INVISIBLE

        b.statusText.text = s.status
        b.detailsBtn.isVisible = s.failed && !s.busy
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(b.urlInput.windowToken, 0)
        b.urlInput.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private val URL_REGEX = Regex("""https?://\S+""")
        fun extractUrl(text: String): String? =
            URL_REGEX.find(text)?.value?.trimEnd('.', ',', ')', ']', '"', '\'')
    }
}
