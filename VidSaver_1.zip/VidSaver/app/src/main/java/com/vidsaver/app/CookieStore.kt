/*
 * VidSaver
 * Copyright © 2026 KKsarkar. All rights reserved.
 */

package com.vidsaver.app

import android.content.Context
import android.webkit.CookieManager
import java.io.File

/** A site the user can sign in to so yt-dlp can download login-only videos. */
data class LoginSite(
    val name: String,
    val loginUrl: String,
    /** cookie domain, e.g. "instagram.com" */
    val domain: String,
)

/**
 * Saves the WebView login cookies into a Netscape "cookies.txt" file, which yt-dlp reads with --cookies.
 */
object CookieStore {

    val sites = listOf(
        LoginSite("Instagram", "https://www.instagram.com/accounts/login/", "instagram.com"),
        LoginSite("Facebook", "https://m.facebook.com/login/", "facebook.com"),
        LoginSite("TikTok", "https://www.tiktok.com/login", "tiktok.com"),
        LoginSite("X (Twitter)", "https://x.com/i/flow/login", "x.com"),
    )

    private fun file(ctx: Context) = File(ctx.filesDir, "cookies.txt")

    // yt-dlp rewrites this file after each run and marks HttpOnly cookies with a "#HttpOnly_" prefix,
    // so those lines are real cookies, not comments.
    private const val HTTP_ONLY = "#HttpOnly_"
    private fun isCookieLine(l: String) = l.isNotBlank() && (!l.startsWith("#") || l.startsWith(HTTP_ONLY))
    private fun isFor(l: String, site: LoginSite): Boolean {
        val host = l.removePrefix(HTTP_ONLY).substringBefore('\t').trimStart('.')
        return host == site.domain || host.endsWith(".${site.domain}")
    }

    /** The cookies file, only if at least one site is signed in. */
    fun fileIfAny(ctx: Context): File? {
        val f = file(ctx)
        return if (f.exists() && f.readLines().any { isCookieLine(it) }) f else null
    }

    fun isSignedIn(ctx: Context, site: LoginSite): Boolean {
        val f = file(ctx)
        if (!f.exists()) return false
        return f.readLines().any { isCookieLine(it) && isFor(it, site) }
    }

    /** Copies the WebView cookies of [site] into cookies.txt. Returns how many cookies were saved. */
    fun saveFromWebView(ctx: Context, site: LoginSite): Int {
        val cm = CookieManager.getInstance()
        cm.flush()
        val pairs = linkedMapOf<String, String>()
        for (url in listOf("https://www.${site.domain}", "https://m.${site.domain}", "https://${site.domain}")) {
            val raw = cm.getCookie(url) ?: continue
            raw.split(';').forEach { part ->
                val i = part.indexOf('=')
                if (i > 0) pairs[part.substring(0, i).trim()] = part.substring(i + 1).trim()
            }
        }
        val expiry = System.currentTimeMillis() / 1000 + 365L * 24 * 60 * 60
        val newLines = pairs.map { (k, v) -> ".${site.domain}\tTRUE\t/\tTRUE\t$expiry\t$k\t$v" }
        writeLines(ctx, keep = { !isFor(it, site) }, add = newLines)
        return newLines.size
    }

    fun signOut(ctx: Context, site: LoginSite) {
        writeLines(ctx, keep = { !isFor(it, site) }, add = emptyList())
        val cm = CookieManager.getInstance()
        for (url in listOf("https://www.${site.domain}", "https://m.${site.domain}", "https://${site.domain}")) {
            cm.getCookie(url)?.split(';')?.forEach { part ->
                val name = part.substringBefore('=').trim()
                if (name.isNotEmpty()) cm.setCookie(url, "$name=; Max-Age=0; Domain=.${site.domain}; Path=/")
            }
        }
        cm.flush()
    }

    private fun writeLines(ctx: Context, keep: (String) -> Boolean, add: List<String>) {
        val f = file(ctx)
        val old = if (f.exists()) f.readLines().filter { isCookieLine(it) && keep(it) } else emptyList()
        val all = old + add
        f.writeText("# Netscape HTTP Cookie File\n" + all.joinToString("\n") + if (all.isEmpty()) "" else "\n")
    }
}
