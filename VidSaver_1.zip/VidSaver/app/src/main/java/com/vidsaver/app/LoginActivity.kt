/*
 * VidSaver
 * Copyright © 2026 KKsarkar. All rights reserved.
 */

package com.vidsaver.app

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Opens a site's login page in a WebView. When the user taps "Done", the login cookies are
 * saved for yt-dlp (see CookieStore).
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var site: LoginSite

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        site = CookieStore.sites.firstOrNull { it.domain == intent.getStringExtra(EXTRA_DOMAIN) }
            ?: run { finish(); return }
        title = getString(R.string.sign_in_to, site.name)

        val pad = (8 * resources.displayMetrics.density).toInt()
        val done = MaterialButton(this).apply {
            text = getString(R.string.login_done)
            setOnClickListener { saveAndClose() }
        }
        web = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            // Some sites refuse logins from an embedded "wv" browser; look like normal Chrome.
            settings.userAgentString = settings.userAgentString.replace("; wv", "")
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            setPadding(pad, pad, pad, 0)
            addView(done, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(web)
        }
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else saveAndClose()
            }
        })

        if (savedInstanceState == null) web.loadUrl(site.loginUrl) else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    private fun saveAndClose() {
        val n = CookieStore.saveFromWebView(this, site)
        val msg = if (CookieStore.isSignedIn(this, site) && n > 0)
            getString(R.string.login_saved, site.name) else getString(R.string.login_not_saved)
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        finish()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_DOMAIN = "domain"
    }
}
