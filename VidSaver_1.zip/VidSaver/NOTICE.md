# VidSaver — Copyright & Notices

**VidSaver** is owned by **KKsarkar**.
Copyright © 2026 KKsarkar. All rights reserved.
The VidSaver name, the VidSaver app icon and the KKsarkar logo (`branding/`) are the property of KKsarkar.

## Open-source components used
| Component | License |
|---|---|
| [youtubedl-android](https://github.com/yausername/youtubedl-android) | GPL-3.0 |
| [yt-dlp](https://github.com/yt-dlp/yt-dlp) | Unlicense (public domain) |
| [FFmpeg](https://ffmpeg.org) (bundled by youtubedl-android) | GPL |
| [yt-dlp-threads](https://github.com/tribixbite/yt-dlp-threads) plugin | Unlicense (public domain) |
| AndroidX, Material Components | Apache-2.0 |
| Google Mobile Ads SDK | Google terms |

Because youtubedl-android and FFmpeg are GPL-licensed, anyone who receives the APK is entitled
to the app's source code under GPL-3.0 terms. KKsarkar keeps the copyright to its own code,
name and logos.
