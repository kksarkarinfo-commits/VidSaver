package com.vidsaver.app

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.vidsaver.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: DownloadViewModel by viewModels()
    private var adView: AdView? = null

    private var pending: Pair<String, Boolean>? = null
    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val p = pending
            pending = null
            if (granted && p != null) vm.download(p.first, p.second)
            else if (!granted) toast("Storage permission is needed to save files")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.urlLayout.setEndIconOnClickListener { pasteFromClipboard() }
        b.downloadBtn.setOnClickListener { startDownload() }
        b.urlInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { startDownload(); true } else false
        }
        b.cancelBtn.setOnClickListener { vm.cancel() }
        b.updateBtn.setOnClickListener { vm.updateYtDlp() }
        b.detailsBtn.setOnClickListener { showLog() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { render(it) }
            }
        }

        setupAds()

        if (savedInstanceState == null) handleShare(intent)
    }

    // ---------- Ads ----------

    private fun setupAds() {
        lifecycleScope.launch {
            // Google recommends initializing the SDK off the main thread.
            withContext(Dispatchers.IO) { MobileAds.initialize(this@MainActivity) {} }
            loadBanner()
        }
    }

    private fun loadBanner() {
        val metrics = resources.displayMetrics
        // screen width minus the 20dp padding on each side of the layout
        val widthDp = (metrics.widthPixels / metrics.density).toInt() - 40
        val view = AdView(this).apply {
            adUnitId = getString(R.string.admob_banner_id)
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this@MainActivity, widthDp))
        }
        b.adContainer.removeAllViews()
        b.adContainer.addView(view)
        adView = view
        view.loadAd(AdRequest.Builder().build())
    }

    override fun onResume() {
        super.onResume()
        adView?.resume()
    }

    override fun onPause() {
        adView?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        adView?.destroy()
        adView = null
        super.onDestroy()
    }

    // ---------- Error details ----------

    private fun showLog() {
        val log = vm.state.value.log.ifEmpty { "—" }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val text = TextView(this).apply {
            this.text = log
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(pad, pad, pad, pad)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(text) }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.details_title)
            .setView(scroll)
            .setPositiveButton(R.string.close, null)
            .setNeutralButton(R.string.copy) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("VidSaver log", log))
                toast("Copied")
            }
            .show()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val url = extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()) ?: return
        b.urlInput.setText(url)
        toast("Link added — choose Video or Audio and tap Download")
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        val url = text?.let { extractUrl(it) }
        if (url != null) b.urlInput.setText(url) else toast("No link found in clipboard")
    }

    private fun startDownload() {
        val url = extractUrl(b.urlInput.text?.toString().orEmpty())
        if (url == null) {
            b.urlLayout.error = "Enter a valid link (https://…)"
            return
        }
        b.urlLayout.error = null
        hideKeyboard()
        val audioOnly = b.formatGroup.checkedButtonId == R.id.btnAudio

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending = url to audioOnly
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        vm.download(url, audioOnly)
    }

    private fun render(s: UiState) {
        b.downloadBtn.isEnabled = s.ready && !s.busy
        b.updateBtn.isEnabled = s.ready && !s.busy
        b.cancelBtn.isVisible = s.canCancel

        val showBar = s.busy
        val wantIndeterminate = s.progress < 0
        if (b.progress.isIndeterminate != wantIndeterminate) {
            // Material requires the bar to be hidden while switching modes.
            b.progress.visibility = View.INVISIBLE
            b.progress.isIndeterminate = wantIndeterminate
        }
        if (!wantIndeterminate) b.progress.setProgressCompat(s.progress, true)
        b.progress.visibility = if (showBar) View.VISIBLE else View.INVISIBLE

        b.statusText.text = s.status
        b.detailsBtn.isVisible = s.failed && !s.busy
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(b.urlInput.windowToken, 0)
        b.urlInput.clearFocus()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private val URL_REGEX = Regex("""https?://\S+""")
        fun extractUrl(text: String): String? =
            URL_REGEX.find(text)?.value?.trimEnd('.', ',', ')', ']', '"', '\'')
    }
}
