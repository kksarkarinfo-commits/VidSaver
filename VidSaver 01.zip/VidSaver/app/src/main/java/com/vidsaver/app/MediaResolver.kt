/*
 * VidSaver
 * Copyright © 2026 KKsarkar. All rights reserved.
 */

package com.vidsaver.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

/** One downloadable file (a single quality version of one video). */
data class MediaVersion(val url: String, val width: Int, val height: Int) {
    /** "Resolution" the way people mean it: the short side (1080 for both 1920x1080 and 1080x1920). */
    val res: Int get() = if (width > 0 && height > 0) minOf(width, height) else maxOf(width, height)
}

/** Videos found in a post. Each inner list = the quality versions of one video (a carousel can have several). */
data class ResolvedMedia(val site: String, val id: String, val videos: List<List<MediaVersion>>, val referer: String)

/**
 * Finds direct video links for sites where yt-dlp alone can't do it on Android:
 *  - Instagram: yt-dlp's logged-out method needs "curl_cffi" (browser impersonation), which Android lacks.
 *    We ask Instagram directly through Android's own network stack instead.
 *  - X/Twitter: when the guest API returns no video, ask the public fxtwitter / vxtwitter APIs.
 *  - Facebook: share links redirect logged-out users to login.php?next=<real link>; take the real link.
 */
object MediaResolver {

    private const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private const val IG_APP_ID = "936619743392459"
    private const val IG_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"

    // ------------------------------------------------------------------ URL helpers

    fun host(url: String): String = try { URI(url.trim()).host.orEmpty().lowercase() } catch (_: Exception) { "" }

    private fun hostIs(url: String, vararg domains: String): Boolean {
        val h = host(url)
        return domains.any { h == it || h.endsWith(".$it") }
    }

    fun isInstagram(url: String) = hostIs(url, "instagram.com", "instagr.am")
    fun isTwitter(url: String) = hostIs(url, "x.com", "twitter.com", "mobile.twitter.com")
    fun isFacebook(url: String) = hostIs(url, "facebook.com", "fb.watch", "fb.com")

    fun instagramShortcode(url: String): String? =
        Regex("""instagram\.com/(?:[^/?#]+/)?(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)""").find(url)?.groupValues?.get(1)

    /** Instagram shortcode -> numeric media id (same as yt-dlp's _id_to_pk). */
    fun shortcodeToPk(shortcode: String): String {
        val code = if (shortcode.length > 28) shortcode.dropLast(28) else shortcode
        var n = BigInteger.ZERO
        val base = BigInteger.valueOf(64)
        for (c in code) {
            val i = IG_CHARS.indexOf(c)
            require(i >= 0) { "bad shortcode" }
            n = n.multiply(base).add(BigInteger.valueOf(i.toLong()))
        }
        return n.toString()
    }

    fun tweetId(url: String): String? = Regex("""/status(?:es)?/(\d+)""").find(url)?.groupValues?.get(1)

    /** If [url] is a Facebook login page, return the page it wanted to open ("next"), else null. */
    fun facebookLoginNext(url: String): String? {
        if (!isFacebook(url) || !url.contains("login")) return null
        val query = try { URI(url).rawQuery } catch (_: Exception) { null } ?: return null
        val next = query.split('&').firstOrNull { it.startsWith("next=") }?.substringAfter("next=") ?: return null
        val decoded = URLDecoder.decode(next, "UTF-8")
        return decoded.takeIf { it.startsWith("http") }
    }

    fun isFacebookStory(url: String) = isFacebook(url) && url.contains("/stories/")

    /** Pick the version to download: Auto (0) = the best the link has, otherwise the best not above [maxRes]. */
    fun pick(versions: List<MediaVersion>, maxRes: Int): MediaVersion? {
        if (versions.isEmpty()) return null
        val byQuality = versions.sortedWith(compareBy<MediaVersion>({ it.res }, { it.width * it.height }))
        if (maxRes <= 0) return byQuality.last()
        return byQuality.lastOrNull { it.res in 1..maxRes } ?: byQuality.first()
    }

    // ------------------------------------------------------------------ parsers (pure, unit-tested)

    private fun versionsFrom(arr: JSONArray?): List<MediaVersion> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val v = arr.optJSONObject(i) ?: return@mapNotNull null
            val u = v.optString("url")
            if (u.startsWith("http")) MediaVersion(u, v.optInt("width"), v.optInt("height")) else null
        }.distinctBy { it.url }
    }

    /** Instagram "product" (API item / xig_polaris_media.if_not_gated_logged_out). */
    fun parseInstagramProduct(p: JSONObject): List<List<MediaVersion>> {
        val carousel = p.optJSONArray("carousel_media")
        val nodes = if (carousel != null && carousel.length() > 0)
            (0 until carousel.length()).mapNotNull { carousel.optJSONObject(it) } else listOf(p)
        return nodes.map { versionsFrom(it.optJSONArray("video_versions")) }.filter { it.isNotEmpty() }
    }

    /** Older GraphQL shape: data.xdt_shortcode_media / data.shortcode_media. */
    fun parseInstagramShortcodeMedia(m: JSONObject): List<List<MediaVersion>> {
        val edges = m.optJSONObject("edge_sidecar_to_children")?.optJSONArray("edges")
        val nodes = if (edges != null && edges.length() > 0)
            (0 until edges.length()).mapNotNull { edges.optJSONObject(it)?.optJSONObject("node") } else listOf(m)
        return nodes.mapNotNull { n ->
            val u = n.optString("video_url")
            if (!u.startsWith("http")) return@mapNotNull null
            val d = n.optJSONObject("dimensions")
            listOf(MediaVersion(u, d?.optInt("width") ?: 0, d?.optInt("height") ?: 0))
        }
    }

    fun unescapeJs(s: String): String = s
        .replace("\\\\/", "/").replace("\\/", "/")
        .replace("\\\\u0026", "&").replace("\\u0026", "&")
        .replace("\\\\\"", "\"").replace("\\\"", "\"")
        .replace("&amp;", "&")

    /** Video links inside an Instagram embed page or any HTML with "video_url" / og:video / <video src>. */
    fun parseHtmlVideoUrls(html: String): List<String> {
        val text = unescapeJs(html)
        val found = LinkedHashSet<String>()
        Regex(""""video_url"\s*:\s*"(https://[^"]+)"""").findAll(text).forEach { found += it.groupValues[1] }
        Regex("""<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']""")
            .findAll(text).forEach { found += it.groupValues[1] }
        Regex("""<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:video(?::secure_url)?["']""")
            .findAll(text).forEach { found += it.groupValues[1] }
        Regex("""<video[^>]+src=["'](https://[^"']+)["']""").findAll(text).forEach { found += it.groupValues[1] }
        return found.filter { it.startsWith("https://") }.toList()
    }

    /** Only the og:video tag (describes THIS post; safe to use on a full post page). */
    fun parseOgVideo(html: String): List<String> {
        val text = unescapeJs(html)
        val found = LinkedHashSet<String>()
        Regex("""<meta[^>]+property=["']og:video(?::secure_url)?["'][^>]+content=["']([^"']+)["']""")
            .findAll(text).forEach { found += it.groupValues[1] }
        Regex("""<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:video(?::secure_url)?["']""")
            .findAll(text).forEach { found += it.groupValues[1] }
        return found.filter { it.startsWith("https://") }.toList()
    }

    /** fxtwitter: {"tweet":{"media":{"videos":[{"url","width","height"}]}}} */
    fun parseFxTwitter(json: JSONObject): List<List<MediaVersion>> {
        val videos = json.optJSONObject("tweet")?.optJSONObject("media")?.optJSONArray("videos") ?: return emptyList()
        return (0 until videos.length()).mapNotNull { i ->
            val v = videos.optJSONObject(i) ?: return@mapNotNull null
            val list = mutableListOf<MediaVersion>()
            v.optJSONArray("variants")?.let { arr ->
                for (j in 0 until arr.length()) {
                    val o = arr.optJSONObject(j) ?: continue
                    val u = o.optString("url")
                    if (u.startsWith("http") && (o.optString("content_type").contains("mp4") || u.contains(".mp4"))) {
                        val wh = Regex("""/(\d+)x(\d+)/""").find(u)?.groupValues
                        list += MediaVersion(u, wh?.get(1)?.toInt() ?: 0, wh?.get(2)?.toInt() ?: 0)
                    }
                }
            }
            val main = v.optString("url")
            if (main.startsWith("http")) list += MediaVersion(main, v.optInt("width"), v.optInt("height"))
            list.distinctBy { it.url }.takeIf { it.isNotEmpty() }
        }
    }

    /** vxtwitter: {"media_extended":[{"type":"video","url","size":{"width","height"}}]} */
    fun parseVxTwitter(json: JSONObject): List<List<MediaVersion>> {
        val arr = json.optJSONArray("media_extended") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val m = arr.optJSONObject(i) ?: return@mapNotNull null
            val type = m.optString("type")
            val u = m.optString("url")
            if ((type == "video" || type == "gif") && u.startsWith("http")) {
                val size = m.optJSONObject("size")
                listOf(MediaVersion(u, size?.optInt("width") ?: 0, size?.optInt("height") ?: 0))
            } else null
        }
    }

    // ------------------------------------------------------------------ tiny HTTP client with cookies

    private class Http(private val log: (String) -> Unit) {
        private val cookies = LinkedHashMap<String, String>()

        class Resp(val code: Int, val body: String, val url: String, val location: String?)

        fun cookie(name: String) = cookies[name]

        fun request(
            url: String, ua: String, headers: Map<String, String> = emptyMap(),
            form: Map<String, String>? = null, follow: Boolean = true,
        ): Resp {
            var current = url
            repeat(8) {
                val c = (URL(current).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 15_000
                    readTimeout = 20_000
                    setRequestProperty("User-Agent", ua)
                    setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                    if (cookies.isNotEmpty()) setRequestProperty("Cookie", cookies.entries.joinToString("; ") { "${it.key}=${it.value}" })
                    headers.forEach { (k, v) -> setRequestProperty(k, v) }
                    if (form != null) {
                        requestMethod = "POST"
                        doOutput = true
                        setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    }
                }
                try {
                    if (form != null) {
                        val body = form.entries.joinToString("&") {
                            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
                        }
                        c.outputStream.use { it.write(body.toByteArray()) }
                    }
                    val code = c.responseCode
                    c.headerFields["Set-Cookie"]?.forEach { sc ->
                        val kv = sc.substringBefore(';')
                        val k = kv.substringBefore('=').trim()
                        val v = kv.substringAfter('=', "").trim()
                        if (k.isNotEmpty() && v.isNotEmpty() && v != "\"\"") cookies[k] = v
                    }
                    val loc = c.getHeaderField("Location")?.let { URL(URL(current), it).toString() }
                    if (code in 300..399 && loc != null) {
                        if (!follow || form != null) return Resp(code, "", current, loc)
                        current = loc
                        return@repeat
                    }
                    val stream = if (code >= 400) c.errorStream else c.inputStream
                    val text = stream?.bufferedReader()?.use { r ->
                        val sb = StringBuilder()
                        val buf = CharArray(16 * 1024)
                        while (sb.length < 6_000_000) { val n = r.read(buf); if (n < 0) break; sb.append(buf, 0, n) }
                        sb.toString()
                    }.orEmpty()
                    return Resp(code, text, current, loc)
                } finally {
                    c.disconnect()
                }
            }
            throw IOException("Too many redirects")
        }
    }

    // ------------------------------------------------------------------ Instagram

    fun resolveInstagram(url: String, log: (String) -> Unit): ResolvedMedia? {
        val code = instagramShortcode(url) ?: return null
        val http = Http(log)
        val referer = "https://www.instagram.com/p/$code/"
        log("[VidSaver] Instagram $code: opening post page")
        val page = try { http.request(referer, DESKTOP_UA, mapOf("Accept" to "text/html")) } catch (e: Exception) {
            log("[VidSaver] page failed: ${e.message}"); null
        }

        page?.body?.let { html ->
            parseOgVideo(html).takeIf { it.isNotEmpty() }?.let { urls ->
                log("[VidSaver] found og:video in the page")
                return ResolvedMedia("Instagram", code, urls.map { listOf(MediaVersion(it, 0, 0)) }, referer)
            }
        }

        var lsd = page?.body?.let { lsdFrom(it) }
        if (lsd == null) {
            lsd = try { lsdFrom(http.request("https://www.instagram.com/", DESKTOP_UA).body) } catch (_: Exception) { null }
        }
        val csrf = http.cookie("csrftoken")
        log("[VidSaver] session: lsd=${if (lsd != null) "ok" else "missing"}, csrf=${if (csrf != null) "ok" else "missing"}")

        val apiHeaders = buildMap {
            put("X-IG-App-ID", IG_APP_ID)
            put("X-ASBD-ID", "359341")
            put("X-IG-WWW-Claim", "0")
            put("Origin", "https://www.instagram.com")
            put("Referer", referer)
            put("Accept", "*/*")
            put("X-Requested-With", "XMLHttpRequest")
            lsd?.let { put("X-FB-LSD", it) }
            csrf?.let { put("X-CSRFToken", it) }
        }

        // 1) Same logged-out GraphQL query yt-dlp uses (but via Android's TLS, which Instagram accepts).
        if (lsd != null) {
            try {
                val r = http.request("https://www.instagram.com/api/graphql", DESKTOP_UA,
                    apiHeaders + ("X-FB-Friendly-Name" to "PolarisLoggedOutDesktopWWWPostRootContentQuery"),
                    form = mapOf(
                        "lsd" to lsd, "fb_api_caller_class" to "RelayModern",
                        "fb_api_req_friendly_name" to "PolarisLoggedOutDesktopWWWPostRootContentQuery",
                        "server_timestamps" to "true",
                        "variables" to "{\"media_id\":\"${shortcodeToPk(code)}\"}",
                        "doc_id" to "27130156389949648",
                    ))
                val product = JSONObject(r.body).optJSONObject("data")?.optJSONObject("xig_polaris_media")
                    ?.optJSONObject("if_not_gated_logged_out")
                val videos = product?.let { parseInstagramProduct(it) }.orEmpty()
                log("[VidSaver] graphql #1: HTTP ${r.code}, videos=${videos.size}")
                if (videos.isNotEmpty()) return ResolvedMedia("Instagram", code, videos, referer)
            } catch (e: Exception) { log("[VidSaver] graphql #1 failed: ${e.message}") }

            // 2) The "shortcode" GraphQL query many web downloaders use.
            try {
                val vars = "{\"shortcode\":\"$code\",\"fetch_tagged_user_count\":null,\"hoisted_comment_id\":null,\"hoisted_reply_id\":null}"
                val r = http.request("https://www.instagram.com/graphql/query", DESKTOP_UA,
                    apiHeaders + ("X-FB-Friendly-Name" to "PolarisPostActionLoadPostQueryQuery"),
                    form = mapOf(
                        "av" to "0", "__d" to "www", "__user" to "0", "__a" to "1", "lsd" to lsd,
                        "fb_api_caller_class" to "RelayModern",
                        "fb_api_req_friendly_name" to "PolarisPostActionLoadPostQueryQuery",
                        "variables" to vars, "server_timestamps" to "true", "doc_id" to "8845758582119845",
                    ))
                val data = JSONObject(r.body).optJSONObject("data")
                val m = data?.optJSONObject("xdt_shortcode_media") ?: data?.optJSONObject("shortcode_media")
                val videos = m?.let { parseInstagramShortcodeMedia(it) }.orEmpty()
                log("[VidSaver] graphql #2: HTTP ${r.code}, videos=${videos.size}")
                if (videos.isNotEmpty()) return ResolvedMedia("Instagram", code, videos, referer)
            } catch (e: Exception) { log("[VidSaver] graphql #2 failed: ${e.message}") }
        }

        // 3) The public embed page (what websites show when they embed a post).
        for (embed in listOf("https://www.instagram.com/p/$code/embed/captioned/", "https://www.instagram.com/p/$code/embed/")) {
            try {
                val r = http.request(embed, MOBILE_UA, mapOf("Accept" to "text/html", "Referer" to "https://www.google.com/"))
                val urls = parseHtmlVideoUrls(r.body)
                log("[VidSaver] embed: HTTP ${r.code}, videos=${urls.size}")
                if (urls.isNotEmpty()) return ResolvedMedia("Instagram", code, urls.map { listOf(MediaVersion(it, 0, 0)) }, referer)
            } catch (e: Exception) { log("[VidSaver] embed failed: ${e.message}") }
        }

        // 4) API v1 info endpoint (sometimes answers logged-out requests).
        try {
            val r = http.request("https://www.instagram.com/api/v1/media/${shortcodeToPk(code)}/info/", DESKTOP_UA, apiHeaders)
            val item = JSONObject(r.body).optJSONArray("items")?.optJSONObject(0)
            val videos = item?.let { parseInstagramProduct(it) }.orEmpty()
            log("[VidSaver] api v1: HTTP ${r.code}, videos=${videos.size}")
            if (videos.isNotEmpty()) return ResolvedMedia("Instagram", code, videos, referer)
        } catch (e: Exception) { log("[VidSaver] api v1 failed: ${e.message}") }

        return null
    }

    private fun lsdFrom(html: String): String? =
        Regex("""\["LSD",\[\],\{"token":"([^"]+)"""").find(html)?.groupValues?.get(1)
            ?: Regex(""""lsd"\s*:\s*"([^"]+)"""").find(html)?.groupValues?.get(1)
            ?: Regex("""<script[^>]*id="__eqmc"[^>]*>.*?"l"\s*:\s*"([^"]+)"""", RegexOption.DOT_MATCHES_ALL).find(html)?.groupValues?.get(1)

    // ------------------------------------------------------------------ X / Twitter

    fun resolveTwitter(url: String, log: (String) -> Unit): ResolvedMedia? {
        val id = tweetId(url) ?: return null
        val http = Http(log)
        val referer = "https://x.com/i/status/$id"
        try {
            val r = http.request("https://api.fxtwitter.com/status/$id", MOBILE_UA, mapOf("Accept" to "application/json"))
            val videos = parseFxTwitter(JSONObject(r.body))
            log("[VidSaver] fxtwitter: HTTP ${r.code}, videos=${videos.size}")
            if (videos.isNotEmpty()) return ResolvedMedia("X", id, videos, referer)
        } catch (e: Exception) { log("[VidSaver] fxtwitter failed: ${e.message}") }
        try {
            val r = http.request("https://api.vxtwitter.com/Twitter/status/$id", MOBILE_UA, mapOf("Accept" to "application/json"))
            val videos = parseVxTwitter(JSONObject(r.body))
            log("[VidSaver] vxtwitter: HTTP ${r.code}, videos=${videos.size}")
            if (videos.isNotEmpty()) return ResolvedMedia("X", id, videos, referer)
        } catch (e: Exception) { log("[VidSaver] vxtwitter failed: ${e.message}") }
        return null
    }

    // ------------------------------------------------------------------ Facebook

    /**
     * Turns a Facebook share link (facebook.com/share/..., fb.watch/...) into the real post link.
     * Logged-out users get sent to login.php?next=<real link>; we take that "next" link.
     */
    fun resolveFacebookLink(url: String, log: (String) -> Unit): String {
        facebookLoginNext(url)?.let { return cleanFacebookUrl(it) }
        val needs = host(url).endsWith("fb.watch") || Regex("""facebook\.com/share/""").containsMatchIn(url)
        if (!needs) return url
        val http = Http(log)
        var current = url
        repeat(6) {
            val r = try { http.request(current, MOBILE_UA, mapOf("Accept" to "text/html"), follow = false) } catch (e: Exception) {
                log("[VidSaver] facebook link resolve failed: ${e.message}"); return current
            }
            val loc = r.location ?: return current
            facebookLoginNext(loc)?.let { next ->
                val clean = cleanFacebookUrl(next)
                log("[VidSaver] facebook share link -> $clean")
                return clean
            }
            if (loc.contains("/login")) return current
            current = loc
        }
        log("[VidSaver] facebook share link -> $current")
        return current
    }

    /** Drop tracking parameters Facebook adds to share links. */
    fun cleanFacebookUrl(url: String): String {
        val u = try { URI(url) } catch (_: Exception) { return url }
        val keep = setOf("v", "story_fbid", "id", "fbid")
        val q = u.rawQuery?.split('&')?.filter { it.substringBefore('=') in keep }?.joinToString("&")
        return buildString {
            append(u.scheme ?: "https").append("://").append(u.host ?: "www.facebook.com").append(u.rawPath ?: "/")
            if (!q.isNullOrEmpty()) append('?').append(q)
        }
    }
}
